# Python imports

# Lib imports
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

# Application imports
from .left_container import LeftContainer
from .center_container import CenterContainer
from .right_container import RightContainer



class BodyContainer(Gtk.Box):
    def __init__(self):
        super(BodyContainer, self).__init__()

        self._setup_styling()
        self._setup_signals()
        self._subscribe_to_events()

        self.show()


    def _setup_styling(self):
        self.ctx = self.get_style_context()
        self.ctx.add_class("body-container")

        self.set_orientation(Gtk.Orientation.HORIZONTAL)

    def _setup_signals(self):
        self.connect("show", self._handle_show)

    def _subscribe_to_events(self):
        ...

    def _handle_show(self, widget):
        self.disconnect_by_func( self._handle_show )
        self._load_widgets()

    def _load_widgets(self):
        widget_registery.expose_object("body-container", self)

        self.add( LeftContainer() )
        self.add( CenterContainer() )
        self.add( RightContainer() )