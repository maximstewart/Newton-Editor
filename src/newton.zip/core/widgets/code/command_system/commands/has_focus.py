# Python imports

# Lib imports
import gi

gi.require_version('GtkSource', '4')

from gi.repository import GtkSource

# Application imports



def execute(
    view: GtkSource.View,
    *args,
    **kwargs
):
    logger.debug("Command: Has Focus")
    ctx = view.get_parent().get_style_context()
    return ctx.has_class("source-view-focused")
