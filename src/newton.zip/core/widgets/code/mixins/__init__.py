"""
    Code Mixins Package
"""