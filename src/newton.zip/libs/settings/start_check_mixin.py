# Python imports
import os
import json
import inspect
from contextlib import suppress

# Lib imports

# Application imports




class StartCheckMixin:
    def is_dirty_start(self) -> bool:
        return self._dirty_start

    def clear_pid(self):
        if not self.is_trace_debug():
            self._clean_pid()

    def do_dirty_start_check(self):
        if self.is_trace_debug():
            pid = os.getpid()
            self._print_pid(pid)
            return

        if os.path.exists(self.path_manager._PID_FILE):
            with open(self.path_manager._PID_FILE, "r") as f:
                pid = f.readline().strip()
                if pid not in ("", None):
                    if self.is_pid_alive( int(pid) ):
                        print("PID file exists and PID is alive... Letting downstream errors (sans debug args) handle app closure propigation.")
                        return

        self._write_new_pid()

    """ Check For the existence of a unix pid. """
    def is_pid_alive(self, pid):
        print(f"PID Found: {pid}")

        try:
            os.kill(pid, 0)
        except OSError:
            print(f"{APP_NAME} PID file exists but PID is irrelevant; starting dirty...")
            self._dirty_start = True
            return False

        return True

    def _write_new_pid(self):
        pid = os.getpid()
        self._write_pid(pid)
        self._print_pid(pid)

    def _print_pid(self, pid):
        print(f"{APP_NAME} PID:  {pid}")

    def _clean_pid(self):
        with suppress(FileNotFoundError, PermissionError):
            os.unlink(self.path_manager._PID_FILE)

    def _write_pid(self, pid):
        with open(self.path_manager._PID_FILE, "w") as _pid:
            _pid.write(f"{pid}")